"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const ask_1 = __importDefault(require("./routes/ask"));
const tts_1 = __importDefault(require("./routes/tts"));
const app = (0, express_1.default)();
app.use((0, cors_1.default)({ origin: 'https://lalu-portfolio.vercel.app' }));
app.use(express_1.default.json());
// Root endpoint
app.get("/", (req, res) => {
    res.send("Lalu Portfolio Backend — Phase 3");
});
// API routes
app.use("/api", ask_1.default);
app.use("/api/tts", tts_1.default); // Add this line
// Start server
const port = process.env.PORT || 8080;
app.listen(port, () => {
    console.log(`Backend listening on http://localhost:${port}`);
});
exports.default = app;
